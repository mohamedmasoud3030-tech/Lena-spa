import "dotenv/config";
import express from "express";
import { createServer as createViteServer } from "vite";
import cookieParser from "cookie-parser";
import jwt from "jsonwebtoken";
import multer from "multer";
import path from "path";
import fs from "fs";

import { prisma, supabase } from "./server/db";
import { JWT_SECRET } from "./server/config";
import * as authController from "./server/controllers/authController";
import * as userController from "./server/controllers/userController";
import * as apiBridgeController from "./server/controllers/apiBridgeController";
import * as dataController from "./server/controllers/dataController";
import * as employeeController from "./server/controllers/employeeController";
import * as serviceController from "./server/controllers/serviceController";
import * as productController from "./server/controllers/productController";
import * as expenseController from "./server/controllers/expenseController";
import * as customerController from "./server/controllers/customerController";
import * as invoiceController from "./server/controllers/invoiceController";
import * as dashboardController from "./server/controllers/dashboardController";
import * as appointmentController from "./server/controllers/appointmentController";
import * as reportController from "./server/controllers/reportController";
import * as activityController from "./server/controllers/activityController";
import * as settingsController from "./server/controllers/settingsController";
import { requireAuth, requireAdmin } from "./server/middleware/authMiddleware";

// Check for DATABASE_URL
const dbUrl = process.env.DATABASE_URL || "";
if (!dbUrl || (!dbUrl.startsWith("postgresql://") && !dbUrl.startsWith("postgres://"))) {
  console.error("\x1b[31m%s\x1b[0m", "CRITICAL ERROR: DATABASE_URL is missing or invalid.");
  if (dbUrl.startsWith("file:")) {
    console.error("\x1b[31m%s\x1b[0m", "It looks like you are still using a local SQLite file path (file:...).");
    console.error("\x1b[31m%s\x1b[0m", "Since we migrated to Supabase, you MUST update DATABASE_URL to your Supabase PostgreSQL connection string.");
  }
  console.error("\x1b[31m%s\x1b[0m", "Please set DATABASE_URL in the AI Studio Settings (e.g., postgresql://postgres:[PASSWORD]@db.[PROJECT_REF].supabase.co:5432/postgres)");
  console.error("\x1b[31m%s\x1b[0m", "The URL must start with 'postgresql://' or 'postgres://'.");
}

// Setup multer for local file uploads
const uploadDir = path.join(process.cwd(), "uploads");
if (!fs.existsSync(uploadDir)) {
  fs.mkdirSync(uploadDir, { recursive: true });
}
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, uploadDir);
  },
  filename: function (req, file, cb) {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
    cb(null, uniqueSuffix + path.extname(file.originalname));
  }
});
const upload = multer({ storage: storage });

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json({ strict: false }));
  app.use(cookieParser());
  app.use("/uploads", express.static(uploadDir)); // Serve uploaded files statically

  // Activity Logger Helper
  async function logActivity(type: string, message: string, userId?: string, meta?: any) {
    try {
      await prisma.activityLog.create({
        data: {
          type: type as any,
          message,
          userId,
          metaJson: meta ? JSON.stringify(meta) : null,
        },
      });
    } catch (e) {
      console.error("Failed to log activity:", e);
    }
  }

  // API Routes
  app.get("/api/health", (req, res) => {
    res.json({ status: "ok" });
  });

  // Auth
  app.get("/api/auth/me", requireAuth, authController.me);
  app.post("/api/auth/login", authController.login);
  app.post("/api/auth/logout", authController.logout);

  // Protect all subsequent API routes
  app.use("/api", requireAuth);

  // Settings
  app.get("/api/settings", settingsController.getSettings);
  app.put("/api/settings", settingsController.updateSettings);
  app.post("/api/settings/logo", requireAdmin, upload.single("logo"), settingsController.uploadLogo);

  // Backup & Restore
  app.get("/api/backup", requireAdmin, dataController.backup);
  app.post("/api/restore", requireAdmin, dataController.restore);

  // Users
  app.get("/api/users", userController.getUsers);
  app.post("/api/users", userController.createUser);
  app.put("/api/users/:id", userController.updateUser);
  app.delete("/api/users/:id", userController.deleteUser);

  // Employees
  app.get("/api/employees", employeeController.getEmployees);
  app.get("/api/employees/commissions", requireAdmin, employeeController.getCommissions);
  app.post("/api/employees", employeeController.createEmployee);
  app.put("/api/employees/:id", employeeController.updateEmployee);
  app.delete("/api/employees/:id", employeeController.deleteEmployee);

  // Services
  app.get("/api/services", serviceController.getServices);
  app.post("/api/services", serviceController.createService);
  app.put("/api/services/:id", serviceController.updateService);
  app.delete("/api/services/:id", serviceController.deleteService);

  // Products
  app.get("/api/products", productController.getProducts);
  app.post("/api/products", productController.createProduct);
  app.put("/api/products/:id", productController.updateProduct);
  app.delete("/api/products/:id", productController.deleteProduct);

  // Expenses
  app.get("/api/expenses", expenseController.getExpenses);
  app.post("/api/expenses", expenseController.createExpense);
  app.delete("/api/expenses/:id", expenseController.deleteExpense);

  // Customers
  app.get("/api/customers", customerController.getCustomers);
  app.get("/api/customers/search", customerController.searchCustomers);
  app.post("/api/customers", customerController.createCustomer);
  app.put("/api/customers/:id", customerController.updateCustomer);
  app.get("/api/customers/:id/history", customerController.getCustomerHistory);

  // Invoices
  app.post("/api/invoices/checkout", invoiceController.checkout);
  app.get("/api/invoices/:id/print", invoiceController.printInvoice);

  // Dashboard
  app.get("/api/dashboard/summary", dashboardController.getSummary);

  // Appointments
  app.get("/api/appointments", appointmentController.getAppointments);
  app.post("/api/appointments", appointmentController.createAppointment);
  app.put("/api/appointments/:id", appointmentController.updateAppointment);

  // Dashboard Extended
  app.get("/api/dashboard/pnl", requireAdmin, dashboardController.getPnl);
  app.get("/api/dashboard/revenue-chart", requireAdmin, dashboardController.getRevenueChart);

  // Reports
  app.get("/api/reports/sales", requireAdmin, reportController.getSales);
  app.get("/api/reports/appointments", requireAdmin, reportController.getAppointments);
  app.get("/api/reports/inventory", requireAdmin, reportController.getInventory);

  // Activity
  app.get("/api/activity", activityController.getActivityLogs);

  // --- Generic API Bridge (for unified call() pattern in Preview) ---
  app.post("/api/:domain/:action", requireAuth, apiBridgeController.handleApiBridge);
      


  // API 404 Handler - Must be before Vite middleware
  app.use("/api/*", (req, res) => {
    res.status(404).json({ error: `API route ${req.originalUrl} not found` });
  });

  // Vite middleware
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { 
        middlewareMode: true,
        hmr: process.env.DISABLE_HMR !== 'true'
      },
      appType: "spa",
    });
    app.use(vite.middlewares);
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
