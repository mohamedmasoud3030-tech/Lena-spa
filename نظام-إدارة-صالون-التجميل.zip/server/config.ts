export const JWT_SECRET = process.env.JWT_SECRET || "kanzy_spa_local_secret_key_2026";
