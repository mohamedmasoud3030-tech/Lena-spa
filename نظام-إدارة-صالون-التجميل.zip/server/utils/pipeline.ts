export interface Pipeline<T = any> {
  send(traveler: T): this;
  through(stops: Array<any> | any): this;
  via(method: string): this;
  then<R = any>(destination: (traveler: T) => any): R;
}

export class PipelineClass<T = any> implements Pipeline<T> {
  private pTraveler: T | null | undefined = null;
  private pStops: Array<any> = [];
  private pMethod: string = "handle";

  /**
   * Set the traveler object being sent on the pipeline.
   */
  send(traveler: T): this {
    this.pTraveler = traveler;
    return this;
  }

  /**
   * Set the stops of the pipeline. Supports array, nested arrays, or variadic arguments.
   */
  through(stops: Array<any> | any): this {
    const list = Array.isArray(stops) ? stops : [stops];
    // Flatten any nested arrays of stops (Laravel-like behavior)
    this.pStops = list.flat(Infinity);
    return this;
  }

  /**
   * Set the method to call on the stops.
   */
  via(method: string): this {
    if (!method || typeof method !== "string") {
      throw new Error("Pipeline method name must be a non-empty string.");
    }
    this.pMethod = method;
    return this;
  }

  /**
   * Run the pipeline with a final destination callback.
   */
  then<R = any>(destination: (traveler: T) => any): R {
    if (this.pTraveler === undefined || this.pTraveler === null) {
      throw new Error("Pipeline traveler has not been set or is null/undefined.");
    }

    if (typeof destination !== "function") {
      throw new Error("Destination callback must be a function.");
    }

    const travelerVal = this.pTraveler;

    const pipeline = this.pStops.reduceRight(
      (stack: (passable: T) => any, stop: any, index: number) => {
        return (passable: T) => {
          try {
            if (typeof stop === "function") {
              return stop(passable, stack);
            } else if (stop && typeof stop[this.pMethod] === "function") {
              return stop[this.pMethod](passable, stack);
            } else {
              throw new Error(
                `Pipeline stage at index ${index} is invalid. It must be a function or an object with the '${this.pMethod}' method.`
              );
            }
          } catch (err: any) {
            // Contextual enrichment for pipeline failures
            const stageName = typeof stop === "function" ? stop.name || `anonymous@stop[${index}]` : `object@stop[${index}]`;
            err.message = `[Pipeline Error at stage '${stageName}']: ${err.message}`;
            throw err;
          }
        };
      },
      (passable: T) => {
        try {
          return destination(passable);
        } catch (err: any) {
          err.message = `[Pipeline Error at destination callback]: ${err.message}`;
          throw err;
        }
      }
    );

    return pipeline(travelerVal);
  }
}

/**
 * Helper function to create a new Pipeline instance.
 */
export function pipeline<T = any>(): Pipeline<T> {
  return new PipelineClass<T>();
}

