import { PrismaClient } from "@prisma/client";
import { createClient } from "@supabase/supabase-js";

export const prisma = new PrismaClient();

const supabaseUrl = process.env.VITE_SUPABASE_URL;
const supabaseAnonKey = process.env.VITE_SUPABASE_ANON_KEY;

const isPlaceholder = (val: string | undefined): boolean => {
  if (!val) return true;
  const v = val.trim();
  return (
    v === "" ||
    v.includes("[PROJECT_REF]") ||
    v.includes("[ANON_KEY]") ||
    v.includes("YOUR_") ||
    v.includes("placeholder") ||
    v.startsWith("https://your") ||
    v.startsWith("https://[") ||
    v.startsWith("http://your") ||
    v.startsWith("http://[")
  );
};

// Supabase has been explicitly disabled per user request ("وقف عمل سربا بيز") to ensure local login handles everything without external API fetch errors
export const supabase = null;
