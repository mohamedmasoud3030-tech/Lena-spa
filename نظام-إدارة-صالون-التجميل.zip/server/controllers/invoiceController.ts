import { Request, Response } from "express";
import { prisma } from "../db";
import { logActivity } from "../services/activityService";
import { pipeline } from "../utils/pipeline";

interface CheckoutContext {
  req: Request;
  customerId: string;
  employeeId: string;
  paymentMethod: string;
  discountAmount: number;
  items: any[];
  useLoyaltyPoints: boolean;
  subtotal: number;
  loyaltyDiscount: number;
  total: number;
  invoiceResult?: any;
}

// PIPELINE STAGES for Checkout Flow

// 1. Calculate subtotal and loyalty discounts
const calculateTotals = async (context: CheckoutContext, next: (ctx: CheckoutContext) => Promise<any>) => {
  context.subtotal = context.items.reduce((sum: number, item: any) => sum + item.price, 0);
  
  context.loyaltyDiscount = 0;
  if (context.useLoyaltyPoints) {
    const customer = await prisma.customer.findUnique({ where: { id: context.customerId } });
    if (customer && customer.loyaltyPoints >= 100) {
      context.loyaltyDiscount = Math.floor(customer.loyaltyPoints / 100);
    }
  }

  context.total = Math.max(0, context.subtotal - (context.discountAmount || 0) - context.loyaltyDiscount);
  return next(context);
};

// 2. Perform safe database transaction containing all side effects
const executeDbTransaction = async (context: CheckoutContext, next: (ctx: CheckoutContext) => Promise<any>) => {
  const result = await prisma.$transaction(async (tx) => {
    const invoice = await tx.invoice.create({
      data: {
        customerId: context.customerId,
        paymentMethod: context.paymentMethod,
        totalAmount: context.total,
        items: {
          create: context.items.map((it: any) => ({
            serviceId: it.kind === "service" ? it.serviceId : undefined,
            productId: it.kind === "product" ? it.productId : undefined,
            price: it.price,
          })),
        },
      },
    });

    for (const item of context.items) {
      if (item.kind === "product" && item.productId) {
        await tx.product.update({
          where: { id: item.productId },
          data: { stockQuantity: { decrement: 1 } },
        });
      }
    }

    await tx.customer.update({
      where: { id: context.customerId },
      data: {
        totalSpent: { increment: context.total },
        loyaltyPoints: { increment: Math.floor(context.total) },
      },
    });

    const emp = await tx.employee.findUnique({ where: { id: context.employeeId } });
    if (emp && emp.commissionPercentage > 0) {
      const comm = (context.total * emp.commissionPercentage) / 100;
      await tx.commission.create({
        data: {
          employeeId: context.employeeId,
          invoiceId: invoice.id,
          amountCalculated: comm,
        },
      });
    }

    return invoice;
  });

  context.invoiceResult = result;
  return next(context);
};

// 3. Log user activity after success
const logTransactionActivity = async (context: CheckoutContext, next: (ctx: CheckoutContext) => Promise<any>) => {
  await logActivity(
    "INVOICE_CREATED", 
    `تم إنشاء فاتورة بقيمة ${context.total.toFixed(2)}`, 
    (context.req as any).user?.id, 
    { invoiceId: context.invoiceResult.id }
  );
  return next(context);
};

export const checkout = async (req: Request, res: Response) => {
  try {
    const { customerId, employeeId, paymentMethod, discountAmount, items, useLoyaltyPoints } = req.body;

    const initialContext: CheckoutContext = {
      req,
      customerId,
      employeeId,
      paymentMethod,
      discountAmount,
      items,
      useLoyaltyPoints,
      subtotal: 0,
      loyaltyDiscount: 0,
      total: 0,
    };

    const finalContext = await pipeline<CheckoutContext>()
      .send(initialContext)
      .through([
        calculateTotals,
        executeDbTransaction,
        logTransactionActivity,
      ])
      .then<Promise<CheckoutContext>>(async (ctx) => ctx);

    res.json({ 
      invoice: finalContext.invoiceResult, 
      pointsEarned: Math.floor(finalContext.total), 
      total: finalContext.total 
    });
  } catch (error: any) {
    res.status(500).json({ error: error.message || "Something went wrong during checkout" });
  }
};

export const printInvoice = async (req: Request, res: Response) => {
  const invoice = await prisma.invoice.findUnique({
    where: { id: req.params.id },
    include: { customer: true, items: { include: { service: true, product: true } } },
  });
  const settings = await prisma.centerSettings.findFirst();
  res.json({ invoice, settings });
};
