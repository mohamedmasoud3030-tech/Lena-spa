import { Request, Response } from "express";
import { prisma } from "../db";
import { logActivity } from "../services/activityService";
import { pipeline } from "../utils/pipeline";

interface CreateAppointmentContext {
  req: Request;
  customerId: string;
  employeeId: string;
  serviceId: string;
  dateTime: Date;
  appointmentResult?: any;
}

// Appointment Pipeline Stops

const validateAppointmentData = async (context: CreateAppointmentContext, next: (ctx: CreateAppointmentContext) => Promise<any>) => {
  if (!context.customerId || !context.employeeId || !context.serviceId || !context.dateTime) {
    throw new Error("Missing required fields for appointment creation");
  }
  return next(context);
};

const persistAppointment = async (context: CreateAppointmentContext, next: (ctx: CreateAppointmentContext) => Promise<any>) => {
  const appointment = await prisma.appointment.create({
    data: {
      customerId: context.customerId,
      employeeId: context.employeeId,
      serviceId: context.serviceId,
      dateTime: context.dateTime,
    },
  });
  context.appointmentResult = appointment;
  return next(context);
};

const logAppointmentActivity = async (context: CreateAppointmentContext, next: (ctx: CreateAppointmentContext) => Promise<any>) => {
  await logActivity(
    "APPOINTMENT_CREATED", 
    `تم حجز موعد جديد`, 
    (context.req as any).user?.id, 
    { appointmentId: context.appointmentResult.id }
  );
  return next(context);
};

export const getAppointments = async (req: Request, res: Response) => {
  const { from, to } = req.query;
  const appointments = await prisma.appointment.findMany({
    where: {
      dateTime: {
        gte: from ? new Date(from as string) : undefined,
        lte: to ? new Date(to as string) : undefined,
      },
    },
    include: { customer: true, employee: true, service: true },
  });
  res.json(appointments);
};

export const createAppointment = async (req: Request, res: Response) => {
  try {
    const { customerId, employeeId, serviceId, dateTime } = req.body;

    const initialContext: CreateAppointmentContext = {
      req,
      customerId,
      employeeId,
      serviceId,
      dateTime: new Date(dateTime),
    };

    const finalContext = await pipeline<CreateAppointmentContext>()
      .send(initialContext)
      .through([
        validateAppointmentData,
        persistAppointment,
        logAppointmentActivity,
      ])
      .then<Promise<CreateAppointmentContext>>(async (ctx) => ctx);

    res.json(finalContext.appointmentResult);
  } catch (error: any) {
    res.status(500).json({ error: error.message || "Failed to create appointment" });
  }
};

export const updateAppointment = async (req: Request, res: Response) => {
  const appointment = await prisma.appointment.update({
    where: { id: req.params.id },
    data: {
      ...req.body,
      dateTime: req.body.dateTime ? new Date(req.body.dateTime) : undefined,
    },
  });
  await logActivity("APPOINTMENT_UPDATED", `تم تحديث حالة الموعد إلى ${appointment.status}`, (req as any).user?.id, { appointmentId: appointment.id });
  res.json(appointment);
};

export const sendReminder = async (req: Request, res: Response) => {
  const id = req.params.id;
  const appt = await prisma.appointment.findUnique({
    where: { id },
    include: { customer: true, service: true },
  });

  if (!appt || !appt.customer?.phone) {
    return res.status(400).json({ error: "Customer phone not found" });
  }

  // Mock SMS sending
  console.log(`[SMS MOCK] Sending reminder to ${appt.customer.phone}: Your appointment for ${appt.service.name} is scheduled for ${appt.dateTime}`);

  await logActivity("APPOINTMENT_UPDATED", `تم إرسال تذكير موعد للعميل ${appt.customer.name}`, (req as any).user?.id);
  res.json({ status: "success", message: "Reminder sent (Mock)" });
};

