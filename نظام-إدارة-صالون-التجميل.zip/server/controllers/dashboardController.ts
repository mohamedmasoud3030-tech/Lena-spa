import { Request, Response } from "express";
import { prisma } from "../db";

export const getSummary = async (req: Request, res: Response) => {
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const firstDayOfMonth = new Date(today.getFullYear(), today.getMonth(), 1);
  
  const todayRevenue = await prisma.invoice.aggregate({
    where: { date: { gte: today } },
    _sum: { totalAmount: true },
  });

  const todayAppointments = await prisma.appointment.count({
    where: { dateTime: { gte: today } },
  });

  const newCustomersThisMonth = await prisma.customer.count({
    where: { createdAt: { gte: firstDayOfMonth } },
  });

  const lowStockProducts = await prisma.product.findMany({
    where: { stockQuantity: { lte: 5 } },
    orderBy: { stockQuantity: 'asc' },
    take: 5,
  });

  const lowStockCount = await prisma.product.count({
    where: { stockQuantity: { lte: 5 } },
  });

  res.json({
    canViewRevenue: (req as any).user.role === "ADMIN",
    todayRevenue: todayRevenue._sum.totalAmount || 0,
    todayAppointments,
    newCustomersThisMonth,
    lowStockCount,
    lowStockTop: lowStockProducts,
  });
};

export const getPnl = async (req: Request, res: Response) => {
  const today = new Date();
  const firstDayOfMonth = new Date(today.getFullYear(), today.getMonth(), 1);

  const revenueAgg = await prisma.invoice.aggregate({
    where: { date: { gte: firstDayOfMonth } },
    _sum: { totalAmount: true },
  });
  const revenue = revenueAgg._sum.totalAmount || 0;

  const employees = await prisma.employee.findMany();
  const baseSalaries = employees.reduce((sum: number, emp: any) => sum + (emp.baseSalary || 0), 0);

  const commissionsAgg = await prisma.commission.aggregate({
    where: { createdAt: { gte: firstDayOfMonth } },
    _sum: { amountCalculated: true },
  });
  const commissions = commissionsAgg._sum.amountCalculated || 0;

  const expensesAgg = await prisma.expense.aggregate({
    where: { date: { gte: firstDayOfMonth } },
    _sum: { amount: true },
  });
  const expenses = expensesAgg._sum.amount || 0;

  res.json({
    revenue,
    baseSalaries,
    commissions,
    expenses,
    profit: revenue - baseSalaries - commissions - expenses,
  });
};

export const getRevenueChart = async (req: Request, res: Response) => {
  const data = [];
  for (let i = 6; i >= 0; i--) {
    const d = new Date();
    d.setDate(d.getDate() - i);
    d.setHours(0, 0, 0, 0);
    const nextDay = new Date(d);
    nextDay.setDate(nextDay.getDate() + 1);

    const agg = await prisma.invoice.aggregate({
      where: { date: { gte: d, lt: nextDay } },
      _sum: { totalAmount: true },
    });

    data.push({
      date: d.toISOString().split('T')[0],
      amount: agg._sum.totalAmount || 0,
    });
  }
  res.json(data);
};
