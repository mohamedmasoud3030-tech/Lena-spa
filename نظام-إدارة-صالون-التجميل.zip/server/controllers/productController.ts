import { Request, Response } from "express";
import { prisma } from "../db";

export const getProducts = async (req: Request, res: Response) => {
  const products = await prisma.product.findMany();
  res.json(products);
};

export const createProduct = async (req: Request, res: Response) => {
  const p = await prisma.product.create({ data: req.body });
  res.json(p);
};

export const updateProduct = async (req: Request, res: Response) => {
  const p = await prisma.product.update({ where: { id: req.params.id }, data: req.body });
  res.json(p);
};

export const deleteProduct = async (req: Request, res: Response) => {
  await prisma.product.delete({ where: { id: req.params.id } });
  res.json({ success: true });
};
