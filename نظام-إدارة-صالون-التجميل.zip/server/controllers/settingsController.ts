import { Request, Response } from "express";
import { prisma } from "../db";

export const getSettings = async (req: Request, res: Response) => {
  try {
    let settings = await prisma.centerSettings.findFirst();
    if (!settings) {
      settings = await prisma.centerSettings.create({
        data: { name: "Kanzy Spa", currency: "OMR" },
      });
    }
    res.json(settings);
  } catch (e: any) {
    res.status(500).json({ error: e.message });
  }
};

export const updateSettings = async (req: Request, res: Response) => {
  try {
    const first = await prisma.centerSettings.findFirst();
    if (!first) return res.status(404).json({ error: "Settings not found" });
    const updated = await prisma.centerSettings.update({
      where: { id: first.id },
      data: req.body,
    });
    res.json(updated);
  } catch (e: any) {
    res.status(500).json({ error: e.message });
  }
};

export const uploadLogo = async (req: Request, res: Response) => {
  if (!req.file) return res.status(400).json({ error: "No file uploaded" });
  
  try {
    const logoPath = `/uploads/${req.file.filename}`;
    const first = await prisma.centerSettings.findFirst();
    if (first) {
      await prisma.centerSettings.update({
        where: { id: first.id },
        data: { logoPath },
      });
    } else {
      await prisma.centerSettings.create({
        data: { name: "Kanzy Spa", currency: "OMR", logoPath },
      });
    }
    res.json({ logoPath });
  } catch (e: any) {
    res.status(500).json({ error: e.message });
  }
};
