import { Request, Response } from "express";
import { prisma } from "../db";

export const backup = async (req: Request, res: Response) => {
  try {
    const data = {
      users: await prisma.user.findMany(),
      customers: await prisma.customer.findMany(),
      services: await prisma.service.findMany(),
      products: await prisma.product.findMany(),
      employees: await prisma.employee.findMany(),
      appointments: await prisma.appointment.findMany(),
      invoices: await prisma.invoice.findMany(),
      invoiceItems: await prisma.invoiceItem.findMany(),
      settings: await prisma.centerSettings.findFirst(),
    };
    res.json(data);
  } catch (e: any) {
    res.status(500).json({ error: e.message });
  }
};

export const restore = async (req: Request, res: Response) => {
  const data = req.body;
  if (!data || !data.users) return res.status(400).json({ error: "Invalid backup file" });
  
  try {
    await prisma.$transaction(async (tx) => {
      // Delete all existing data in correct order to respect foreign keys
      await tx.invoiceItem.deleteMany();
      await tx.invoice.deleteMany();
      await tx.appointment.deleteMany();
      await tx.employee.deleteMany();
      await tx.product.deleteMany();
      await tx.service.deleteMany();
      await tx.customer.deleteMany();
      await tx.user.deleteMany();
      await tx.centerSettings.deleteMany();

      // Insert new data
      if (data.users?.length) await tx.user.createMany({ data: data.users });
      if (data.customers?.length) await tx.customer.createMany({ data: data.customers });
      if (data.services?.length) await tx.service.createMany({ data: data.services });
      if (data.products?.length) await tx.product.createMany({ data: data.products });
      if (data.employees?.length) await tx.employee.createMany({ data: data.employees });
      if (data.appointments?.length) await tx.appointment.createMany({ data: data.appointments });
      if (data.invoices?.length) await tx.invoice.createMany({ data: data.invoices });
      if (data.invoiceItems?.length) await tx.invoiceItem.createMany({ data: data.invoiceItems });
      if (data.settings) await tx.centerSettings.create({ data: data.settings });
    });

    res.json({ success: true });
  } catch (e: any) {
    res.status(500).json({ error: "Restore failed: " + e.message });
  }
};
