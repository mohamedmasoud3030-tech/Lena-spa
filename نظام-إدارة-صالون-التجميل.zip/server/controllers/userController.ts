import { Request, Response } from "express";
import bcrypt from "bcryptjs";
import { prisma } from "../db";

export const getUsers = async (req: Request, res: Response) => {
  const users = await prisma.user.findMany({
    select: { id: true, username: true, role: true, isActive: true, createdAt: true },
  });
  res.json(users);
};

export const createUser = async (req: Request, res: Response) => {
  try {
    const hash = await bcrypt.hash(req.body.password, 10);
    const user = await prisma.user.create({
      data: {
        username: req.body.username,
        passwordHash: hash,
        role: req.body.role,
        isActive: req.body.isActive,
      },
    });
    res.json(user);
  } catch (e: any) {
    res.status(500).json({ error: e.message });
  }
};

export const updateUser = async (req: Request, res: Response) => {
  try {
    const data: any = { role: req.body.role, isActive: req.body.isActive };
    if (req.body.password) {
      data.passwordHash = await bcrypt.hash(req.body.password, 10);
    }
    const user = await prisma.user.update({
      where: { id: req.params.id },
      data,
    });
    res.json(user);
  } catch (e: any) {
    res.status(500).json({ error: e.message });
  }
};

export const deleteUser = async (req: Request, res: Response) => {
  try {
    await prisma.user.delete({ where: { id: req.params.id } });
    res.json({ success: true });
  } catch (e: any) {
    res.status(500).json({ error: e.message });
  }
};
