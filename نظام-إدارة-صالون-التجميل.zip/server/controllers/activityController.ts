import { Request, Response } from "express";
import { prisma } from "../db";

export const getActivityLogs = async (req: Request, res: Response) => {
  const logs = await prisma.activityLog.findMany({
    take: Number(req.query.take) || 20,
    orderBy: { createdAt: "desc" },
    include: { user: { select: { username: true } } },
  });
  res.json(logs);
};
