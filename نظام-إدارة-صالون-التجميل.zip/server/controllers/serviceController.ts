import { Request, Response } from "express";
import { prisma } from "../db";

export const getServices = async (req: Request, res: Response) => {
  const services = await prisma.service.findMany();
  res.json(services);
};

export const createService = async (req: Request, res: Response) => {
  const s = await prisma.service.create({ data: req.body });
  res.json(s);
};

export const updateService = async (req: Request, res: Response) => {
  const s = await prisma.service.update({ where: { id: req.params.id }, data: req.body });
  res.json(s);
};

export const deleteService = async (req: Request, res: Response) => {
  await prisma.service.delete({ where: { id: req.params.id } });
  res.json({ success: true });
};
