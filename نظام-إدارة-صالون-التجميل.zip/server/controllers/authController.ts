import { Request, Response } from "express";
import jwt from "jsonwebtoken";
import bcrypt from "bcryptjs";
import { prisma, supabase } from "../db";
import { JWT_SECRET } from "../config";

export const me = async (req: any, res: Response) => {
  res.json({ userId: req.user.id, role: req.user.role, username: req.user.username });
};

export const login = async (req: Request, res: Response) => {
  const { username, password } = req.body;
  console.log(`Login attempt for: ${username}`);
  try {
    // 1. Try Supabase Auth first if configured
    if (supabase) {
      const { data: sbData, error: sbError } = await supabase.auth.signInWithPassword({
        email: username,
        password: password,
      });

      if (!sbError && sbData.user) {
        console.log(`Supabase login successful for: ${username}`);
        // Ensure user exists in Prisma for role/activity tracking
        let user = await prisma.user.findUnique({ where: { username: username.toLowerCase() } });
        if (!user) {
          user = await prisma.user.create({
            data: {
              username: username.toLowerCase(),
              passwordHash: "SUPABASE_AUTH", // Placeholder
              role: username.toLowerCase() === "mohamedmasoud303@gmail.com" ? "ADMIN" : "STAFF",
              isActive: true,
            },
          });
        }

        const token = jwt.sign({ userId: user.id, role: user.role }, JWT_SECRET, { expiresIn: "7d" });
        res.cookie("token", token, { 
          httpOnly: true, 
          secure: true, 
          sameSite: 'none', 
          maxAge: 7 * 24 * 60 * 60 * 1000 
        });
        
        return res.json({ userId: user.id, role: user.role, username: user.username });
      }
      
      if (sbError) {
        console.log(`Supabase login failed for: ${username}: ${sbError.message}`);
        return res.status(401).json({ error: sbError.message });
      }
    }

    // 2. Local Auth Fallback (Only if Supabase is NOT configured)
    if (!supabase) {
      // Self-healing: Ensure at least one admin user exists if database is empty
      const userCount = await prisma.user.count().catch(() => 0);
      if (userCount === 0) {
        const defaultPasswordHash = await bcrypt.hash("admin123", 10);
        await prisma.user.create({
          data: {
            username: "mohamedmasoud303@gmail.com",
            passwordHash: defaultPasswordHash,
            role: "ADMIN",
            isActive: true,
          }
        }).catch(err => console.error("Failed to seed default admin user mohamedmasoud:", err));

        await prisma.user.create({
          data: {
            username: "admin",
            passwordHash: defaultPasswordHash,
            role: "ADMIN",
            isActive: true,
          }
        }).catch(err => console.error("Failed to seed default admin username:", err));
      }

      const user = await prisma.user.findUnique({ 
        where: { username: username.toLowerCase() } 
      });
      
      if (!user || !user.isActive) {
        return res.status(401).json({ error: "Invalid credentials" });
      }

      const valid = await bcrypt.compare(password, user.passwordHash);
      if (!valid) {
        return res.status(401).json({ error: "Invalid credentials" });
      }

      const token = jwt.sign({ userId: user.id, role: user.role }, JWT_SECRET, { expiresIn: "7d" });
      res.cookie("token", token, { 
        httpOnly: true, 
        secure: true, 
        sameSite: 'none', 
        maxAge: 7 * 24 * 60 * 60 * 1000 
      });
      
      return res.json({ userId: user.id, role: user.role, username: user.username });
    }

    return res.status(401).json({ error: "Supabase not configured" });
  } catch (e: any) {
    console.error("Login error:", e);
    if (e.message?.includes("DATABASE_URL")) {
      return res.status(500).json({ 
        error: "Database connection error. Please ensure DATABASE_URL is correctly set in AI Studio Settings." 
      });
    }
    res.status(500).json({ error: e.message });
  }
};

export const logout = (req: Request, res: Response) => {
  res.clearCookie("token");
  res.json({ success: true });
};
