import { Request, Response } from "express";
import { prisma } from "../db";

export const getCustomers = async (req: Request, res: Response) => {
  const c = await prisma.customer.findMany();
  res.json(c);
};

export const searchCustomers = async (req: Request, res: Response) => {
  const q = req.query.q as string;
  const c = await prisma.customer.findMany({
    where: { OR: [{ name: { contains: q } }, { phone: { contains: q } }] },
    take: 20,
  });
  res.json(c);
};

export const createCustomer = async (req: Request, res: Response) => {
  const c = await prisma.customer.create({ data: req.body });
  res.json(c);
};

export const updateCustomer = async (req: Request, res: Response) => {
  const c = await prisma.customer.update({
    where: { id: req.params.id },
    data: req.body,
  });
  res.json(c);
};

export const getCustomerHistory = async (req: Request, res: Response) => {
  const invoices = await prisma.invoice.findMany({
    where: { customerId: req.params.id },
    include: { items: { include: { service: true, product: true } } },
    orderBy: { date: "desc" },
  });
  const appointments = await prisma.appointment.findMany({
    where: { customerId: req.params.id },
    include: { service: true, employee: true },
    orderBy: { dateTime: "desc" },
  });
  res.json({ invoices, appointments });
};
