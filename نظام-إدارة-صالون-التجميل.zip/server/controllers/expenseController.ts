import { Request, Response } from "express";
import { prisma } from "../db";
import { logActivity } from "../services/activityService";

export const getExpenses = async (req: Request, res: Response) => {
  const expenses = await prisma.expense.findMany({ orderBy: { date: "desc" } });
  res.json(expenses);
};

export const createExpense = async (req: Request, res: Response) => {
  const expense = await prisma.expense.create({ data: req.body });
  await logActivity("SETTINGS_UPDATED", `تم تسجيل مصروف جديد: ${expense.description}`, (req as any).user?.id);
  res.json(expense);
};

export const deleteExpense = async (req: Request, res: Response) => {
  await prisma.expense.delete({ where: { id: req.params.id } });
  res.json({ success: true });
};
