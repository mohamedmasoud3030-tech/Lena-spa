import { Request, Response } from "express";
import { prisma } from "../db";

export const getSales = async (req: Request, res: Response) => {
  const { from, to } = req.query;
  const invoices = await prisma.invoice.findMany({
    where: {
      date: {
        gte: from ? new Date(from as string) : undefined,
        lte: to ? new Date(to as string) : undefined,
      },
    },
    orderBy: { date: "asc" },
  });
  res.json(invoices);
};

export const getAppointments = async (req: Request, res: Response) => {
  const { from, to } = req.query;
  const appts = await prisma.appointment.findMany({
    where: {
      dateTime: {
        gte: from ? new Date(from as string) : undefined,
        lte: to ? new Date(to as string) : undefined,
      },
    },
    include: { customer: true, employee: true, service: true },
    orderBy: { dateTime: "asc" },
  });
  res.json(appts);
};

export const getInventory = async (req: Request, res: Response) => {
  const products = await prisma.product.findMany({
    orderBy: { stockQuantity: "asc" },
  });
  res.json(products);
};
