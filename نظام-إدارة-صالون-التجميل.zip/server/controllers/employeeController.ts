import { Request, Response } from "express";
import { prisma } from "../db";

export const getEmployees = async (req: Request, res: Response) => {
  const employees = await prisma.employee.findMany();
  res.json(employees);
};

export const getCommissions = async (req: Request, res: Response) => {
  const today = new Date();
  const firstDayOfMonth = new Date(today.getFullYear(), today.getMonth(), 1);
  
  const employees = await prisma.employee.findMany({
    include: {
      commissions: {
        where: { createdAt: { gte: firstDayOfMonth } },
      },
    },
  });
  res.json(employees);
};

export const createEmployee = async (req: Request, res: Response) => {
  const emp = await prisma.employee.create({ data: req.body });
  res.json(emp);
};

export const updateEmployee = async (req: Request, res: Response) => {
  const emp = await prisma.employee.update({ where: { id: req.params.id }, data: req.body });
  res.json(emp);
};

export const deleteEmployee = async (req: Request, res: Response) => {
  await prisma.employee.delete({ where: { id: req.params.id } });
  res.json({ success: true });
};
