import { Request, Response } from "express";

import * as authController from "./authController";
import * as userController from "./userController";
import * as employeeController from "./employeeController";
import * as serviceController from "./serviceController";
import * as productController from "./productController";
import * as expenseController from "./expenseController";
import * as customerController from "./customerController";
import * as invoiceController from "./invoiceController";
import * as dashboardController from "./dashboardController";
import * as appointmentController from "./appointmentController";
import * as reportController from "./reportController";
import * as activityController from "./activityController";
import * as dataController from "./dataController";
import * as settingsController from "./settingsController";

export const handleApiBridge = async (req: any, res: Response) => {
  const { domain, action } = req.params;
  const payload = req.body;

  try {
    // --- RBAC Protection for sensitive domains ---
    const sensitiveDomains = ["reports", "settings", "users", "expenses", "employees"];
    if (sensitiveDomains.includes(domain) && (req as any).user?.role !== "ADMIN") {
      return res.status(403).json({ error: "Access Denied: Admins only" });
    }

    // Helper to adapt Request for controllers
    const adaptReq = (customParams: any = {}, customQuery: any = {}) => {
      return {
        ...req,
        params: { ...req.params, ...customParams },
        query: { ...req.query, ...customQuery },
        body: payload, // payload is already parsed
      } as any;
    };

    // --- Route to respective controllers ---

    // Auth
    if (domain === "auth") {
      if (action === "me") return await authController.me(req, res);
      if (action === "login") return await authController.login(req, res);
      if (action === "logout") return await authController.logout(req, res);
    }

    // Activity
    if (domain === "activity" && action === "latest") {
      const take = typeof payload === "number" ? payload : 20;
      return await activityController.getActivityLogs(adaptReq({}, { take: String(take) }), res);
    }

    // Dashboard
    if (domain === "dashboard") {
      if (action === "summary") return await dashboardController.getSummary(req, res);
      if (action === "pnlMonth") return await dashboardController.getPnl(req, res);
      if (action === "revenueLast7Days") return await dashboardController.getRevenueChart(req, res);
    }

    // Reports
    if (domain === "reports") {
      if (action === "sales") return await reportController.getSales(adaptReq({}, { from: payload?.from, to: payload?.to }), res);
      if (action === "appointments") return await reportController.getAppointments(adaptReq({}, { from: payload?.from, to: payload?.to }), res);
      if (action === "inventory") return await reportController.getInventory(req, res);
    }

    // Settings
    if (domain === "settings") {
      if (action === "get") return await settingsController.getSettings(req, res);
      if (action === "update") return await settingsController.updateSettings(req, res);
      if (action === "backup") return await dataController.backup(req, res);
      if (action === "exportData") return await dataController.backup(req, res); // export data is equivalent to backup
      if (action === "restore") return await dataController.restore(req, res);
    }

    // Users
    if (domain === "users") {
      if (action === "list" || action === "listFull") return await userController.getUsers(req, res);
      if (action === "create") return await userController.createUser(req, res);
      if (action === "update") return await userController.updateUser(adaptReq({ id: payload.id }), res);
      if (action === "delete") {
        const id = typeof payload === "string" ? payload : payload.id;
        return await userController.deleteUser(adaptReq({ id }), res);
      }
    }

    // Employees
    if (domain === "employees") {
      if (action === "list" || action === "listFull") return await employeeController.getEmployees(req, res);
      if (action === "listWithMonthCommissions") return await employeeController.getCommissions(req, res);
      if (action === "create") return await employeeController.createEmployee(req, res);
      if (action === "update") return await employeeController.updateEmployee(adaptReq({ id: payload.id }), res);
      if (action === "delete") {
        const id = typeof payload === "string" ? payload : payload.id;
        return await employeeController.deleteEmployee(adaptReq({ id }), res);
      }
    }

    // Products
    if (domain === "products") {
      if (action === "list" || action === "listFull") return await productController.getProducts(req, res);
      if (action === "create") return await productController.createProduct(req, res);
      if (action === "update") return await productController.updateProduct(adaptReq({ id: payload.id }), res);
      if (action === "delete") {
        const id = typeof payload === "string" ? payload : payload.id;
        return await productController.deleteProduct(adaptReq({ id }), res);
      }
    }

    // Services
    if (domain === "services") {
      if (action === "list" || action === "listFull") return await serviceController.getServices(req, res);
      if (action === "create") return await serviceController.createService(req, res);
      if (action === "update") return await serviceController.updateService(adaptReq({ id: payload.id }), res);
      if (action === "delete") {
        const id = typeof payload === "string" ? payload : payload.id;
        return await serviceController.deleteService(adaptReq({ id }), res);
      }
    }

    // Expenses
    if (domain === "expenses") {
      if (action === "list" || action === "listFull") return await expenseController.getExpenses(req, res);
      if (action === "create") return await expenseController.createExpense(req, res);
      if (action === "delete") {
        const id = typeof payload === "string" ? payload : payload.id;
        return await expenseController.deleteExpense(adaptReq({ id }), res);
      }
    }

    // Customers
    if (domain === "customers") {
      if (action === "list" || action === "listFull") return await customerController.getCustomers(req, res);
      if (action === "search") {
        const q = typeof payload === "string" ? payload : payload.q || "";
        return await customerController.searchCustomers(adaptReq({}, { q }), res);
      }
      if (action === "create") return await customerController.createCustomer(req, res);
      if (action === "update") return await customerController.updateCustomer(adaptReq({ id: payload.id }), res);
      if (action === "history") {
        const id = typeof payload === "string" ? payload : payload.id;
        return await customerController.getCustomerHistory(adaptReq({ id }), res);
      }
    }

    // Invoices
    if (domain === "invoices") {
      if (action === "checkout") return await invoiceController.checkout(req, res);
      if (action === "getForPrint" || action === "print") {
        const id = typeof payload === "string" ? payload : payload.id;
        return await invoiceController.printInvoice(adaptReq({ id }), res);
      }
    }

    // Appointments
    if (domain === "appointments") {
      if (action === "list") return await appointmentController.getAppointments(adaptReq({}, { from: payload?.from, to: payload?.to }), res);
      if (action === "create") return await appointmentController.createAppointment(req, res);
      if (action === "update") return await appointmentController.updateAppointment(adaptReq({ id: payload.id }), res);
      if (action === "sendReminder") {
        const id = typeof payload === "string" ? payload : payload.id;
        return await appointmentController.sendReminder(adaptReq({ id }), res);
      }
    }

    res.status(404).json({ error: "Action not found" });
  } catch (e: any) {
    res.status(500).json({ error: e.message });
  }
};
