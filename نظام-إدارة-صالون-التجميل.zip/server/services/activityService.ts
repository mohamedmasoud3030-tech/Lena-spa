import { prisma } from "../db";

export async function logActivity(type: string, message: string, userId?: string, meta?: any) {
  try {
    await prisma.activityLog.create({
      data: {
        type: type as any,
        message,
        userId,
        metaJson: meta ? JSON.stringify(meta) : null,
      },
    });
  } catch (e) {
    console.error("Failed to log activity:", e);
  }
}
