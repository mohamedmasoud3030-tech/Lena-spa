import { Outlet, useLocation } from "react-router-dom";
import Sidebar from "./Sidebar";
import { useAuth } from "../../auth";
import { Menu, Bell, Search, ChevronRight, LayoutGrid, Sparkles, Zap, Star } from "lucide-react";
import { useState, useEffect, useMemo } from "react";
import { useTranslation } from "react-i18next";
import { motion, AnimatePresence } from "motion/react";
import { clsx } from "clsx";

export default function Layout() {
  const { me, logout } = useAuth();
  const { t, i18n } = useTranslation();
  const [showSidebar, setShowSidebar] = useState(false);
  const location = useLocation();

  // Dynamically sync language and direction on document element
  useEffect(() => {
    const currentLang = i18n.language || 'ar';
    document.documentElement.lang = currentLang;
    document.documentElement.dir = currentLang === 'ar' ? 'rtl' : 'ltr';
  }, [i18n.language]);

  // Close sidebar on route change (mobile)
  useEffect(() => {
    setShowSidebar(false);
  }, [location.pathname]);

  const pageTitle = useMemo(() => {
    const path = location.pathname.substring(1);
    if (!path) return t("Dashboard");
    return t(path.charAt(0).toUpperCase() + path.slice(1));
  }, [location.pathname, t]);

  const isRtl = i18n.language === "ar";

  return (
    <div className="min-h-screen bg-background text-foreground selection:bg-primary/30 selection:text-primary-foreground">
      <div className="lg:grid lg:min-h-screen lg:grid-cols-[320px_1fr] relative">
        
        {/* Mobile Sidebar Overlay */}
        <AnimatePresence>
          {showSidebar && (
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 z-45 bg-black/60 backdrop-blur-sm lg:hidden"
              onClick={() => setShowSidebar(false)}
            />
          )}
        </AnimatePresence>

        {/* Sidebar Container */}
        <div className={clsx(
          "fixed inset-y-0 z-50 w-[320px] transform transition-all duration-500 ease-[0.23,1,0.32,1] lg:static lg:translate-x-0 shadow-2xl lg:shadow-none",
          isRtl ? "right-0 border-l border-border" : "left-0 border-r border-border",
          showSidebar 
            ? "translate-x-0" 
            : (isRtl ? "translate-x-full lg:translate-x-0" : "-translate-x-full lg:translate-x-0")
        )}>
          <Sidebar onClose={() => setShowSidebar(false)} />
        </div>

        <div className="flex min-w-0 flex-col relative">
          {/* Immersive Background Elements */}
          <div className="absolute inset-0 z-0 pointer-events-none overflow-hidden">
            <div className="absolute top-[-10%] right-[-10%] w-[40%] h-[40%] bg-primary/5 blur-[120px] rounded-full" />
            <div className="absolute bottom-[-10%] left-[-10%] w-[40%] h-[40%] bg-accent/5 blur-[120px] rounded-full" />
          </div>

          <header className="sticky top-0 z-30 flex h-24 items-center justify-between border-b border-border bg-card/40 px-4 sm:px-8 lg:px-10 backdrop-blur-3xl shadow-sm">
            <div className="flex items-center gap-4 sm:gap-6">
              <button 
                onClick={() => setShowSidebar(true)}
                className="h-12 w-12 rounded-2xl bg-muted/50 flex items-center justify-center text-muted-foreground hover:bg-primary/10 hover:text-primary lg:hidden transition-all shadow-sm"
              >
                <Menu className="h-6 w-6" />
              </button>
              
              <div className="hidden sm:flex items-center gap-4">
                <div className="h-10 w-10 rounded-xl bg-primary/10 flex items-center justify-center text-primary shadow-inner">
                  <LayoutGrid className="h-5 w-5" />
                </div>
                <div className="flex items-center gap-3">
                  <h2 className="text-sm font-bold uppercase tracking-[0.3em] text-muted-foreground/60">
                    {pageTitle}
                  </h2>
                  <ChevronRight className={clsx("h-4 w-4 text-muted-foreground/30", isRtl && "rotate-180")} />
                  <div className="flex items-center gap-2 px-3 py-1 rounded-full bg-primary/5 border border-primary/10">
                    <Sparkles className="h-3 w-3 text-primary animate-pulse" />
                    <span className="text-[10px] font-bold text-primary uppercase tracking-widest">{t("Live")}</span>
                  </div>
                </div>
              </div>
            </div>

            <div className="flex items-center gap-4 sm:gap-6">
              <div className="hidden md:flex items-center gap-3 bg-muted/30 p-2 rounded-2xl border border-border shadow-inner group focus-within:ring-4 focus-within:ring-primary/10 focus-within:border-primary transition-all">
                <Search className="h-4 w-4 text-muted-foreground group-focus-within:text-primary ml-2" />
                <input 
                  type="text" 
                  placeholder={t("Search anything...")}
                  className="bg-transparent border-none outline-none text-xs font-bold text-foreground placeholder:text-muted-foreground/50 w-28 sm:w-48"
                />
              </div>

              <div className="flex items-center gap-3 sm:gap-4">
                <button className="h-12 w-12 rounded-2xl bg-muted/50 flex items-center justify-center text-muted-foreground hover:bg-primary/10 hover:text-primary transition-all shadow-sm relative group">
                  <Bell className="h-5 w-5 group-hover:rotate-12 transition-transform" />
                  <span className="absolute top-3 right-3 h-2.5 w-2.5 rounded-full bg-primary border-2 border-card shadow-sm" />
                </button>
                
                <div className="h-10 w-px bg-border mx-1 hidden sm:block" />
                
                <div className="hidden sm:flex flex-col items-end">
                  <span className="text-sm font-bold text-foreground tracking-tight">{me?.username}</span>
                  <div className="flex items-center gap-1.5 mt-1">
                    <div className="h-1.5 w-1.5 rounded-full bg-emerald-500 shadow-[0_0_8px_rgba(16,185,129,0.5)]" />
                    <span className="text-[10px] font-bold uppercase tracking-widest text-primary opacity-80">
                      {me?.role === "ADMIN" ? t("Administrator") : t("Staff Member")}
                    </span>
                  </div>
                </div>
                
                <div className="h-12 w-12 rounded-2xl bg-primary/10 border border-primary/20 flex items-center justify-center text-primary font-bold text-lg shadow-inner hover:scale-110 transition-transform cursor-pointer">
                  {me?.username?.[0]?.toUpperCase()}
                </div>
              </div>
            </div>
          </header>

          <main className="min-w-0 flex-1 p-4 sm:p-8 lg:p-12 relative z-10">
            <AnimatePresence mode="wait">
              <motion.div
                key={location.pathname}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                transition={{ duration: 0.4, ease: [0.23, 1, 0.32, 1] }}
              >
                <Outlet />
              </motion.div>
            </AnimatePresence>
          </main>

          <footer className="h-auto py-6 sm:h-20 border-t border-border/50 flex flex-col sm:flex-row items-center justify-between gap-4 px-6 sm:px-12 bg-card/20 backdrop-blur-sm">
            <div className="flex items-center gap-6">
              <div className="flex items-center gap-2 text-[10px] font-bold text-muted-foreground uppercase tracking-widest opacity-50">
                <Zap className="h-3 w-3" />
                {t("System Online")}
              </div>
              <div className="flex items-center gap-2 text-[10px] font-bold text-muted-foreground uppercase tracking-widest opacity-50">
                <Star className="h-3 w-3" />
                {t("Premium Build")}
              </div>
            </div>
            <div className="text-[10px] font-bold text-muted-foreground uppercase tracking-[0.3em] opacity-30 text-center sm:text-right">
              &copy; {new Date().getFullYear()} KANZY SPA &bull; {t("All Rights Reserved")}
            </div>
          </footer>
        </div>
      </div>
    </div>
  );
}
