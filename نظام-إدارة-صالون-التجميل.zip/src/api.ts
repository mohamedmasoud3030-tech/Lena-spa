export async function call(domain: string, action: string, payload?: any): Promise<any> {
  // Fallback to Express Server (Preview/Dev Mode)
  // This allows the app to work in the browser preview using the real backend
  try {
    const url = `/api/${domain}/${action}`;
    const response = await fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload || {}),
    });

    if (!response.ok) {
      const errData = await response.json().catch(() => ({}));
      throw new Error(errData.error || `Server Error: ${response.status}`);
    }

    return await response.json();
  } catch (error: any) {
    if (error.message !== "Not logged in") {
      console.error(`Server API Error [${domain}:${action}]:`, error);
    }
    throw error;
  }
}

// Legacy compatibility for existing pages (will be removed in next steps)
export const api = {
  auth: {
    me: () => call("auth", "me"),
    login: (data: any) => call("auth", "login", data),
    logout: () => call("auth", "logout"),
  },
  users: {
    list: () => call("users", "list"),
    create: (data: any) => call("users", "create", data),
    update: (data: any) => call("users", "update", data),
    delete: (id: string) => call("users", "delete", id),
  },
  settings: {
    get: () => call("settings", "get"),
    update: (data: any) => call("settings", "update", data),
    uploadLogo: async (file: File) => {
      const formData = new FormData();
      formData.append("logo", file);
      const response = await fetch("/api/settings/logo", {
        method: "POST",
        body: formData,
      });
      if (!response.ok) {
        const errData = await response.json().catch(() => ({}));
        throw new Error(errData.error || `Server Error: ${response.status}`);
      }
      return await response.json();
    },
    backup: () => call("settings", "backup"),
    restore: (data: any) => call("settings", "restore", data),
    exportData: () => call("settings", "exportData"),
  },
  activity: {
    latest: (take?: number) => call("activity", "latest", take),
  },
  services: {
    list: () => call("services", "list"),
    create: (data: any) => call("services", "create", data),
    update: (data: any) => call("services", "update", data),
    delete: (id: string) => call("services", "delete", id),
  },
  customers: {
    search: (q: string) => call("customers", "search", q),
    list: () => call("customers", "list"),
    create: (data: any) => call("customers", "create", data),
    history: (id: string) => call("customers", "history", id),
    update: (id: string, data: any) => call("customers", "update", { id, ...data }),
  },
  expenses: {
    list: () => call("expenses", "list"),
    create: (data: any) => call("expenses", "create", data),
    delete: (id: string) => call("expenses", "delete", id),
  },
  products: {
    list: () => call("products", "list"),
    listFull: () => call("products", "listFull"),
    create: (data: any) => call("products", "create", data),
    update: (data: any) => call("products", "update", data),
    delete: (id: string) => call("products", "delete", id),
  },
  employees: {
    list: () => call("employees", "list"),
    listWithMonthCommissions: () => call("employees", "listWithMonthCommissions"),
    create: (data: any) => call("employees", "create", data),
    update: (data: any) => call("employees", "update", data),
    delete: (id: string) => call("employees", "delete", id),
  },
  invoices: {
    checkout: (payload: any) => call("invoices", "checkout", payload),
    getForPrint: (id: string) => call("invoices", "getForPrint", id),
    print: (id: string) => call("invoices", "print", id),
  },
  reports: {
    sales: (from: string, to: string) => call("reports", "sales", { from, to }),
    appointments: (from: string, to: string) => call("reports", "appointments", { from, to }),
    inventory: () => call("reports", "inventory"),
  },
  appointments: {
    list: (args: any) => call("appointments", "list", args),
    create: (data: any) => call("appointments", "create", data),
    update: (data: any) => call("appointments", "update", data),
    sendReminder: (id: string) => call("appointments", "sendReminder", id),
  },
  dashboard: {
    summary: () => call("dashboard", "summary"),
    pnlMonth: () => call("dashboard", "pnlMonth"),
    revenueLast7Days: () => call("dashboard", "revenueLast7Days"),
  },
};
