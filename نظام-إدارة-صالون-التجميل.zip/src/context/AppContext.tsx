import React, { createContext, useContext, useEffect, useState } from "react";
import { call } from "../api";

interface AppContextType {
  dbMode: "SQLite (Electron)";
  isInitialized: boolean;
  migrationsApplied: number;
  init: () => Promise<void>;
}

const AppContext = createContext<AppContextType | null>(null);

export function AppProvider({ children }: { children: React.ReactNode }) {
  const [dbMode] = useState<"SQLite (Electron)">("SQLite (Electron)");
  const [isInitialized, setIsInitialized] = useState(false);
  const [migrationsApplied] = useState(0);

  async function init() {
    try {
      // In Electron mode, initDB and runMigrations are handled in main process
      // But we can call a ping or self-test to verify
      await call("auth", "me");
      setIsInitialized(true);
      console.log(`[AppContext] Initialized in Electron mode`);
    } catch (error: any) {
      if (error.message === "Not logged in") {
        // This is fine, the app is initialized but user is not logged in
        setIsInitialized(true);
        console.log(`[AppContext] Initialized (Guest Mode)`);
      } else {
        console.error("[AppContext] Initialization failed:", error);
      }
    }
  }

  useEffect(() => {
    void init();
  }, []);

  return (
    <AppContext.Provider value={{ dbMode, isInitialized, migrationsApplied, init }}>
      {children}
    </AppContext.Provider>
  );
}

export function useAppContext() {
  const context = useContext(AppContext);
  if (!context) throw new Error("useAppContext must be used within an AppProvider");
  return context;
}
