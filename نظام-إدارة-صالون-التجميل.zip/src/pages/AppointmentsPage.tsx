import { useEffect, useMemo, useState } from "react";
import { 
  CalendarDays, ChevronLeft, ChevronRight, Plus, X, Clock, 
  User, Scissors, Search, Bell, CheckCircle2, Calendar as CalendarIcon,
  Filter, MoreVertical, Phone, MapPin, Sparkles, XCircle
} from "lucide-react";
import { api } from "../api";
import { clsx } from "clsx";
import { motion, AnimatePresence } from "motion/react";
import { useTranslation } from "react-i18next";
import i18n from "i18next";

type Customer = { id: string; name: string; phone: string | null };
type Service = { id: string; name: string; category: string; durationMins: number; price: number };
type Employee = { id: string; name: string };

type Appt = {
  id: string;
  dateTime: string;
  status: "SCHEDULED" | "CONFIRMED" | "COMPLETED" | "CANCELED";
  customer: Customer;
  employee: Employee;
  service: Service;
};

const SLOT_MINS = 30;

function startOfDay(d: Date) {
  const x = new Date(d);
  x.setHours(0, 0, 0, 0);
  return x;
}

function addDays(d: Date, n: number) {
  const x = new Date(d);
  x.setDate(x.getDate() + n);
  return x;
}

function startOfWeek(d: Date) {
  const x = startOfDay(d);
  const day = x.getDay(); 
  const diff = (day + 1) % 7; 
  return addDays(x, -diff);
}

function fmtDayHeader(d: Date) {
  const lang = i18n.language || "ar";
  return d.toLocaleDateString(lang, { weekday: "short", day: "2-digit", month: "2-digit" });
}

function fmtTime(d: Date) {
  const lang = i18n.language || "ar";
  return d.toLocaleTimeString(lang, { hour: "2-digit", minute: "2-digit" });
}

function statusLabel(s: Appt["status"]) {
  switch (s) {
    case "SCHEDULED": return "معلق";
    case "CONFIRMED": return "مؤكد";
    case "COMPLETED": return "مكتمل";
    case "CANCELED": return "ملغي";
    default: return s;
  }
}

function statusClass(s: Appt["status"]) {
  switch (s) {
    case "SCHEDULED": return "bg-amber-500/10 text-amber-600 border-amber-500/20";
    case "CONFIRMED": return "bg-blue-500/10 text-blue-600 border-blue-500/20";
    case "COMPLETED": return "bg-emerald-500/10 text-emerald-600 border-emerald-500/20";
    case "CANCELED": return "bg-rose-500/10 text-rose-600 border-rose-500/20";
    default: return "bg-muted text-muted-foreground border-border";
  }
}

export default function AppointmentsPage() {
  const { t } = useTranslation();
  const [mode, setMode] = useState<"day" | "week">("week");
  const [anchor, setAnchor] = useState<Date>(() => new Date());

  const [appts, setAppts] = useState<Appt[]>([]);
  const [services, setServices] = useState<Service[]>([]);
  const [employees, setEmployees] = useState<Employee[]>([]);

  const [open, setOpen] = useState(false);
  const [slotDate, setSlotDate] = useState<Date | null>(null);

  const [customerQ, setCustomerQ] = useState("");
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [customerId, setCustomerId] = useState<string>("");

  const [serviceId, setServiceId] = useState<string>("");
  const [employeeId, setEmployeeId] = useState<string>("");
  const [status, setStatus] = useState<Appt["status"]>("SCHEDULED");
  const [busy, setBusy] = useState(false);
  const [loading, setLoading] = useState(false);

  const range = useMemo(() => {
    if (mode === "day") {
      const from = startOfDay(anchor);
      const to = addDays(from, 1);
      return { from, to, days: [from] };
    }
    const from = startOfWeek(anchor);
    const days = Array.from({ length: 7 }, (_, i) => addDays(from, i));
    const to = addDays(from, 7);
    return { from, to, days };
  }, [mode, anchor]);

  async function load() {
    setLoading(true);
    try {
      const [sv, em, a] = await Promise.all([
        api.services.list(),
        api.employees.list(),
        api.appointments.list({ fromISO: range.from.toISOString(), toISO: range.to.toISOString() }),
      ]);
      setServices(sv);
      setEmployees(em);
      setAppts(a);
      if (sv.length && !serviceId) setServiceId(sv[0].id);
      if (em.length && !employeeId) setEmployeeId(em[0].id);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    void load();
  }, [range.from.getTime(), range.to.getTime()]);

  useEffect(() => {
    const t = setTimeout(async () => {
      const q = customerQ.trim();
      if (!q) {
        setCustomers([]);
        return;
      }
      const res = await api.customers.search(q);
      setCustomers(res);
    }, 250);
    return () => clearTimeout(t);
  }, [customerQ]);

  const slots = useMemo(() => {
    const count = (24 * 60) / SLOT_MINS;
    return Array.from({ length: count }, (_, i) => i);
  }, []);

  function slotToDate(day: Date, slotIdx: number) {
    const d = startOfDay(day);
    d.setMinutes(slotIdx * SLOT_MINS, 0, 0);
    return d;
  }

  function openBooking(d?: Date) {
    const targetDate = d || new Date();
    if (!d) {
      const mins = targetDate.getMinutes();
      targetDate.setMinutes(mins >= 30 ? 30 : 0, 0, 0);
    }
    setSlotDate(targetDate);
    setOpen(true);
    setCustomerId("");
    setCustomerQ("");
    setCustomers([]);
    setStatus("SCHEDULED");
  }

  async function submitBooking() {
    if (!slotDate) return;
    if (!customerId) return alert(t("Please select a customer"));
    if (!serviceId) return alert(t("Please select a service"));
    if (!employeeId) return alert(t("Please select an employee"));

    setBusy(true);
    try {
      await api.appointments.create({
        dateTime: slotDate.toISOString(),
        status,
        customerId,
        employeeId,
        serviceId,
      });
      await load();
      setOpen(false);
    } catch (e: any) {
      alert(e.message);
    } finally {
      setBusy(false);
    }
  }

  async function cycleStatus(appt: Appt) {
    const order: Appt["status"][] = ["SCHEDULED", "CONFIRMED", "COMPLETED", "CANCELED"];
    const idx = order.indexOf(appt.status);
    const next = order[(idx + 1) % order.length];
    await api.appointments.update({ id: appt.id, status: next });
    await load();
  }

  async function sendReminder(appt: Appt) {
    if (!appt.customer?.phone) return alert(t("Customer phone number not found"));
    try {
      setBusy(true);
      await api.appointments.sendReminder(appt.id);
      alert(t("Reminder sent successfully (Simulated)"));
    } catch (e: any) {
      alert(e.message);
    } finally {
      setBusy(false);
    }
  }

  const apptsByDay = useMemo(() => {
    const map = new Map<string, Appt[]>();
    for (const a of appts) {
      const d = startOfDay(new Date(a.dateTime)).toISOString();
      map.set(d, [...(map.get(d) ?? []), a]);
    }
    return map;
  }, [appts]);

  return (
    <div className="space-y-8 pb-8">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-8">
        <div className="flex items-center gap-6">
          <div className="h-16 w-16 rounded-[2rem] bg-primary flex items-center justify-center text-primary-foreground shadow-2xl shadow-primary/30 group transition-all hover:scale-110">
            <CalendarDays className="h-8 w-8 transition-transform group-hover:rotate-12" />
          </div>
          <div className="space-y-1">
            <h1 className="text-4xl font-bold text-foreground tracking-tight">{t("Appointments")}</h1>
            <p className="text-sm text-muted-foreground font-medium uppercase tracking-widest">{t("Manage your spa schedule")}</p>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-4">
          <div className="flex items-center gap-2 bg-muted/50 p-2 rounded-[1.5rem] border border-border shadow-inner">
            <button 
              onClick={() => setAnchor(new Date())} 
              className="px-5 py-2.5 text-xs font-bold text-foreground hover:bg-card rounded-xl transition-all shadow-sm"
            >
              {t("Today")}
            </button>
            <div className="flex items-center border-x border-border/50 px-2 gap-2">
              <button 
                onClick={() => setAnchor(d => mode === "day" ? addDays(d, -1) : addDays(d, -7))} 
                className="p-2.5 text-muted-foreground hover:text-primary hover:bg-primary/10 rounded-xl transition-all"
              >
                <ChevronRight className="h-5 w-5" />
              </button>
              <button 
                onClick={() => setAnchor(d => mode === "day" ? addDays(d, 1) : addDays(d, 7))} 
                className="p-2.5 text-muted-foreground hover:text-primary hover:bg-primary/10 rounded-xl transition-all"
              >
                <ChevronLeft className="h-5 w-5" />
              </button>
            </div>
            <div className="flex gap-1.5">
              <button 
                onClick={() => setMode("day")} 
                className={clsx(
                  "px-5 py-2.5 rounded-xl text-xs font-bold transition-all", 
                  mode === "day" ? "bg-card text-primary shadow-md" : "text-muted-foreground hover:text-foreground"
                )}
              >
                {t("Day")}
              </button>
              <button 
                onClick={() => setMode("week")} 
                className={clsx(
                  "px-5 py-2.5 rounded-xl text-xs font-bold transition-all", 
                  mode === "week" ? "bg-card text-primary shadow-md" : "text-muted-foreground hover:text-foreground"
                )}
              >
                {t("Week")}
              </button>
            </div>
          </div>
          <button 
            onClick={() => openBooking()} 
            className="h-14 px-8 rounded-[1.5rem] bg-primary font-bold text-primary-foreground shadow-2xl shadow-primary/30 hover:scale-[1.02] active:scale-[0.98] transition-all flex items-center gap-3"
          >
            <Plus className="h-6 w-6" />
            {t("New Appointment")}
          </button>
        </div>
      </div>

      <motion.div 
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        className="overflow-hidden rounded-[3rem] border border-border bg-card shadow-2xl"
      >
        <div className="overflow-x-auto scrollbar-hide">
          <div className="min-w-[1200px]">
            <div className="grid border-b border-border bg-muted/20" style={{ gridTemplateColumns: `120px repeat(${range.days.length}, 1fr)` }}>
              <div className="p-8 flex items-center justify-center">
                <Clock className="h-6 w-6 text-muted-foreground/40" />
              </div>
              {range.days.map((d) => (
                <div key={d.toISOString()} className="border-r border-border/50 p-8 text-center space-y-1">
                  <div className="text-[10px] font-bold text-muted-foreground uppercase tracking-[0.3em]">{d.toLocaleDateString(i18n.language || "ar", { weekday: "long" })}</div>
                  <div className="text-2xl font-bold text-foreground">{d.toLocaleDateString(i18n.language || "ar", { day: "2-digit", month: "2-digit" })}</div>
                </div>
              ))}
            </div>

            <div className="max-h-[75vh] overflow-y-auto overflow-x-hidden relative scrollbar-hide">
              <div className="grid" style={{ gridTemplateColumns: `120px repeat(${range.days.length}, 1fr)`, gridTemplateRows: `repeat(${slots.length}, 80px)` }}>
                {slots.map((slotIdx) => {
                  const t = slotToDate(range.days[0], slotIdx);
                  const isHour = t.getMinutes() === 0;
                  return (
                    <div key={`time-${slotIdx}`} className="flex items-start justify-center border-b border-border/30 py-4 text-xs font-bold text-muted-foreground/40">
                      {isHour ? fmtTime(t) : ""}
                    </div>
                  );
                })}

                {range.days.map((day) => {
                  const dayKey = startOfDay(day).toISOString();
                  const dayAppts = apptsByDay.get(dayKey) ?? [];
                  return (
                    <div key={dayKey} className="relative border-r border-border/30 group/day">
                      {slots.map((slotIdx) => (
                        <button
                          key={`${dayKey}-${slotIdx}`}
                          onClick={() => openBooking(slotToDate(day, slotIdx))}
                          className="h-[80px] w-full border-b border-border/30 transition-all hover:bg-primary/[0.02] flex items-center justify-center group/slot"
                        >
                          <Plus className="h-4 w-4 text-primary opacity-0 group-hover/slot:opacity-100 transition-opacity" />
                        </button>
                      ))}

                      <div className="pointer-events-none absolute inset-0 p-2">
                        <AnimatePresence>
                          {dayAppts.map((a) => {
                            const dt = new Date(a.dateTime);
                            const minutes = dt.getHours() * 60 + dt.getMinutes();
                            const row = minutes / SLOT_MINS;
                            const span = (a.service?.durationMins ?? 30) / SLOT_MINS;
                            
                            return (
                              <motion.div
                                layoutId={a.id}
                                initial={{ opacity: 0, scale: 0.95, y: 10 }}
                                animate={{ opacity: 1, scale: 1, y: 0 }}
                                exit={{ opacity: 0, scale: 0.95 }}
                                key={a.id}
                                style={{ position: "absolute", top: row * 80 + 8, right: 8, left: 8, height: span * 80 - 16 }}
                                className={clsx(
                                  "pointer-events-auto flex flex-col justify-between rounded-[1.5rem] border p-4 shadow-lg transition-all hover:shadow-2xl hover:-translate-y-0.5 cursor-pointer group/appt",
                                  statusClass(a.status)
                                )}
                                onClick={(e) => { e.stopPropagation(); void cycleStatus(a); }}
                              >
                                <div className="space-y-1.5 min-w-0">
                                  <div className="flex items-start justify-between gap-2">
                                    <div className="truncate text-sm font-bold leading-tight">{a.customer?.name}</div>
                                    <MoreVertical className="h-4 w-4 opacity-0 group-hover/appt:opacity-100 transition-opacity shrink-0" />
                                  </div>
                                  <div className="truncate text-[10px] font-bold uppercase tracking-widest opacity-60 flex items-center gap-1.5">
                                    <Scissors className="h-3 w-3" />
                                    {a.service?.name}
                                  </div>
                                </div>
                                <div className="flex items-center justify-between text-[10px] font-bold mt-2">
                                  <div className="flex items-center gap-2 bg-white/20 px-2 py-1 rounded-lg">
                                    <Clock className="h-3 w-3" />
                                    <span>{fmtTime(dt)}</span>
                                  </div>
                                  <div className="flex items-center gap-2">
                                    {a.status === "SCHEDULED" && (
                                      <button 
                                        onClick={(e) => { e.stopPropagation(); void sendReminder(a); }}
                                        className="h-7 w-7 rounded-xl bg-white/40 flex items-center justify-center hover:bg-white/60 transition-all shadow-sm"
                                      >
                                        <Bell className="h-3.5 w-3.5" />
                                      </button>
                                    )}
                                    <span className="rounded-xl bg-white/50 px-3 py-1 uppercase text-[9px] tracking-wider shadow-sm">{statusLabel(a.status)}</span>
                                  </div>
                                </div>
                              </motion.div>
                            );
                          })}
                        </AnimatePresence>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        </div>
      </motion.div>

      <AnimatePresence>
        {open && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-6">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setOpen(false)}
              className="absolute inset-0 bg-black/60 backdrop-blur-xl"
            />
            <motion.div 
              initial={{ opacity: 0, scale: 0.9, y: 40 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 40 }}
              className="relative w-full max-w-2xl rounded-[3rem] border border-border bg-card shadow-2xl overflow-hidden"
            >
              <div className="flex items-center justify-between border-b border-border px-10 py-8 bg-muted/20">
                <div className="flex items-center gap-4">
                  <div className="h-14 w-14 rounded-2xl bg-primary/10 flex items-center justify-center text-primary shadow-inner">
                    <CalendarIcon className="h-7 w-7" />
                  </div>
                  <div className="space-y-0.5">
                    <h2 className="text-2xl font-bold text-foreground">{t("Book Appointment")}</h2>
                    <p className="text-[10px] font-bold text-muted-foreground uppercase tracking-widest">{t("Fill in the details below")}</p>
                  </div>
                </div>
                <button 
                  onClick={() => setOpen(false)} 
                  className="h-12 w-12 rounded-full hover:bg-muted flex items-center justify-center transition-all hover:rotate-90"
                >
                  <X className="h-6 w-6" />
                </button>
              </div>

              <div className="p-10 space-y-8">
                <div className="grid grid-cols-2 gap-6 p-6 rounded-[2rem] bg-muted/30 border border-border shadow-inner">
                  <div className="space-y-2">
                    <label className="text-[10px] font-bold text-muted-foreground uppercase tracking-[0.2em] ltr:ml-2 rtl:mr-2">{t("Date")}</label>
                    <div className="relative">
                      <CalendarIcon className="absolute ltr:left-4 rtl:right-4 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                      <input 
                        type="date"
                        className="w-full rounded-2xl border border-border bg-card ltr:pl-11 ltr:pr-4 rtl:pr-11 rtl:pl-4 py-3.5 text-sm font-bold outline-none focus:ring-4 focus:ring-primary/10 transition-all text-start"
                        value={slotDate ? `${slotDate.getFullYear()}-${String(slotDate.getMonth() + 1).padStart(2, '0')}-${String(slotDate.getDate()).padStart(2, '0')}` : ''}
                        onChange={(e) => {
                          if (!e.target.value) return;
                          const [y, m, d] = e.target.value.split('-');
                          const newDate = new Date(parseInt(y), parseInt(m) - 1, parseInt(d));
                          if (slotDate) newDate.setHours(slotDate.getHours(), slotDate.getMinutes());
                          setSlotDate(newDate);
                        }}
                      />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <label className="text-[10px] font-bold text-muted-foreground uppercase tracking-[0.2em] ltr:ml-2 rtl:mr-2">{t("Time")}</label>
                    <div className="relative">
                      <Clock className="absolute ltr:left-4 rtl:right-4 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                      <input 
                        type="time"
                        className="w-full rounded-2xl border border-border bg-card ltr:pl-11 ltr:pr-4 rtl:pr-11 rtl:pl-4 py-3.5 text-sm font-bold outline-none focus:ring-4 focus:ring-primary/10 transition-all text-start"
                        value={slotDate ? `${String(slotDate.getHours()).padStart(2, '0')}:${String(slotDate.getMinutes()).padStart(2, '0')}` : ''}
                        onChange={(e) => {
                          if (!e.target.value || !slotDate) return;
                          const [h, m] = e.target.value.split(':');
                          const d = new Date(slotDate);
                          d.setHours(parseInt(h), parseInt(m));
                          setSlotDate(d);
                        }}
                      />
                    </div>
                  </div>
                </div>

                <div className="space-y-3">
                  <label className="text-[10px] font-bold text-muted-foreground uppercase tracking-[0.2em] ltr:ml-2 rtl:mr-2">{t("Customer")}</label>
                  <div className="relative group">
                    <Search className="absolute ltr:left-5 rtl:right-5 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground group-focus-within:text-primary transition-colors" />
                    <input
                      className="w-full rounded-[1.5rem] border border-border bg-card py-4.5 ltr:pl-14 ltr:pr-6 rtl:pr-14 rtl:pl-6 text-sm font-bold focus:ring-4 focus:ring-primary/10 outline-none transition-all"
                      value={customerQ}
                      onChange={(e) => setCustomerQ(e.target.value)}
                      placeholder={t("Search by name or phone...")}
                    />
                    <AnimatePresence>
                      {customers.length > 0 && !customerId && (
                        <motion.div 
                          initial={{ opacity: 0, y: -10 }}
                          animate={{ opacity: 1, y: 0 }}
                          exit={{ opacity: 0, y: -10 }}
                          className="absolute bottom-full left-0 right-0 mb-4 max-h-64 overflow-auto rounded-[2rem] border border-border shadow-2xl bg-card z-10 p-2"
                        >
                          {customers.map((c) => (
                            <button 
                              key={c.id} 
                              onClick={() => { setCustomerId(c.id); setCustomerQ(c.name); }} 
                              className="flex w-full items-center justify-between px-6 py-4 rounded-2xl text-start text-sm hover:bg-muted transition-all group/item"
                            >
                              <div className="flex items-center gap-4">
                                <div className="h-10 w-10 rounded-xl bg-primary/10 flex items-center justify-center text-primary font-bold text-xs group-hover/item:bg-primary group-hover/item:text-primary-foreground transition-colors">{c.name[0]}</div>
                                <div className="text-start">
                                  <span className="font-bold text-foreground block">{c.name}</span>
                                  <span className="text-[10px] text-muted-foreground font-bold tracking-widest">{c.phone}</span>
                                </div>
                              </div>
                              <ChevronRight className={clsx("h-4 w-4 text-muted-foreground opacity-0 group-hover/item:opacity-100 transition-all", i18n.language === "ar" && "rotate-180")} />
                            </button>
                          ))}
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </div>
                  {customerId && (
                    <motion.div 
                      initial={{ opacity: 0, scale: 0.95 }}
                      animate={{ opacity: 1, scale: 1 }}
                      className="flex items-center justify-between p-4 rounded-2xl bg-primary/5 border border-primary/20"
                    >
                      <div className="flex items-center gap-3">
                        <CheckCircle2 className="h-5 w-5 text-primary" />
                        <span className="text-sm font-bold text-foreground">{customerQ}</span>
                      </div>
                      <button onClick={() => { setCustomerId(""); setCustomerQ(""); }} className="text-xs font-bold text-rose-500 hover:underline">{t("Remove")}</button>
                    </motion.div>
                  )}
                </div>

                <div className="grid gap-8 sm:grid-cols-2">
                  <div className="space-y-3">
                    <label className="text-[10px] font-bold text-muted-foreground uppercase tracking-[0.2em] ltr:ml-2 rtl:mr-2">{t("Service")}</label>
                    <div className="relative">
                      <Scissors className="absolute ltr:left-5 rtl:right-5 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
                      <select 
                        className="w-full appearance-none rounded-[1.5rem] border border-border bg-card py-4.5 ltr:pl-14 ltr:pr-12 rtl:pr-14 rtl:pl-12 text-sm font-bold focus:ring-4 focus:ring-primary/10 outline-none transition-all cursor-pointer" 
                        value={serviceId} 
                        onChange={(e) => setServiceId(e.target.value)}
                      >
                        {services.map((s) => <option key={s.id} value={s.id}>{s.name} ({s.durationMins} {t("min")})</option>)}
                      </select>
                      <ChevronRight className="absolute ltr:right-6 rtl:left-6 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground pointer-events-none rotate-90" />
                    </div>
                  </div>

                  <div className="space-y-3">
                    <label className="text-[10px] font-bold text-muted-foreground uppercase tracking-[0.2em] ltr:ml-2 rtl:mr-2">{t("Specialist")}</label>
                    <div className="relative">
                      <User className="absolute ltr:left-5 rtl:right-5 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
                      <select 
                        className="w-full appearance-none rounded-[1.5rem] border border-border bg-card py-4.5 ltr:pl-14 ltr:pr-12 rtl:pr-14 rtl:pl-12 text-sm font-bold focus:ring-4 focus:ring-primary/10 outline-none transition-all cursor-pointer" 
                        value={employeeId} 
                        onChange={(e) => setEmployeeId(e.target.value)}
                      >
                        {employees.map((e) => <option key={e.id} value={e.id}>{e.name}</option>)}
                      </select>
                      <ChevronRight className="absolute ltr:right-6 rtl:left-6 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground pointer-events-none rotate-90" />
                    </div>
                  </div>
                </div>

                <button
                  disabled={busy || !customerId}
                  onClick={submitBooking}
                  className="group relative w-full h-16 rounded-[2rem] bg-primary font-bold text-primary-foreground shadow-2xl shadow-primary/30 hover:scale-[1.02] active:scale-95 transition-all disabled:opacity-50 flex items-center justify-center gap-3 overflow-hidden"
                >
                  <div className="absolute inset-0 bg-gradient-to-tr from-white/0 via-white/10 to-white/0 translate-x-[-100%] group-hover:translate-x-[100%] transition-transform duration-1000" />
                  <CheckCircle2 className="h-6 w-6 relative z-10" />
                  <span className="text-lg relative z-10">{t("Confirm Booking")}</span>
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
