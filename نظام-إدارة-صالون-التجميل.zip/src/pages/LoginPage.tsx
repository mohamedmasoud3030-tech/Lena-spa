import { useEffect } from "react";
import { useNavigate } from "react-router-dom";

export default function LoginPage() {
  const nav = useNavigate();

  useEffect(() => {
    nav("/", { replace: true });
  }, [nav]);

  return (
    <div className="min-h-screen bg-background flex flex-col items-center justify-center p-6 text-center">
      <p className="text-sm text-muted-foreground animate-pulse font-medium">Bypassing login...</p>
    </div>
  );
}
