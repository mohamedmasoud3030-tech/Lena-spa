import { useEffect, useMemo, useState } from "react";
import { useTranslation } from "react-i18next";
import { 
  History, X, Search, User, Phone, Coins, Calendar, 
  Receipt, Plus, FileText, Save, CheckCircle2, UserPlus,
  ChevronRight, MoreVertical, Mail, MapPin, Sparkles, XCircle,
  ArrowUpRight, TrendingUp, Wallet
} from "lucide-react";
import { api } from "../api";
import { clsx } from "clsx";
import { motion, AnimatePresence } from "motion/react";

type Customer = { id: string; name: string; phone: string | null; totalSpent: number; loyaltyPoints: number; notes: string | null };

export default function CustomersPage() {
  const { t, i18n } = useTranslation();
  const [rows, setRows] = useState<Customer[]>([]);
  const [q, setQ] = useState("");
  const [openId, setOpenId] = useState<string | null>(null);
  const [history, setHistory] = useState<any | null>(null);
  const [loading, setLoading] = useState(false);
  const [notes, setNotes] = useState("");
  const [savingNotes, setSavingNotes] = useState(false);

  const [showAddModal, setShowAddModal] = useState(false);
  const [newName, setNewName] = useState("");
  const [newPhone, setNewPhone] = useState("");
  const [adding, setAdding] = useState(false);

  async function load() {
    setLoading(true);
    try {
      const res = await api.customers.list();
      setRows(res);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    void load();
  }, []);

  const filtered = useMemo(() => {
    const text = q.trim().toLowerCase();
    if (!text) return rows;
    return rows.filter((c) => (c.name + " " + (c.phone ?? "")).toLowerCase().includes(text));
  }, [rows, q]);

  async function openHistory(customer: Customer) {
    setOpenId(customer.id);
    setHistory(null);
    setNotes(customer.notes || "");
    const res = await api.customers.history(customer.id);
    setHistory(res);
  }

  async function handleSaveNotes() {
    if (!openId) return;
    setSavingNotes(true);
    try {
      await api.customers.update(openId, { notes });
      alert(t("Notes saved successfully"));
      await load();
    } catch (e: any) {
      alert(e.message);
    } finally {
      setSavingNotes(false);
    }
  }

  async function handleAddCustomer() {
    if (!newName.trim()) return alert(t("Please fill all fields"));
    setAdding(true);
    try {
      await api.customers.create({ name: newName, phone: newPhone || null });
      setNewName("");
      setNewPhone("");
      setShowAddModal(false);
      await load();
    } catch (e: any) {
      alert(e.message);
    } finally {
      setAdding(false);
    }
  }

  return (
    <div className="space-y-10 pb-10">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-8">
        <div className="flex items-center gap-6">
          <div className="h-16 w-16 rounded-[2rem] bg-primary flex items-center justify-center text-primary-foreground shadow-2xl shadow-primary/30 group transition-all hover:scale-110">
            <User className="h-8 w-8 transition-transform group-hover:rotate-12" />
          </div>
          <div className="space-y-1">
            <h1 className="text-4xl font-bold text-foreground tracking-tight">{t("Customers")}</h1>
            <p className="text-sm text-muted-foreground font-medium uppercase tracking-widest">{t("Manage your client database")}</p>
          </div>
        </div>
        
        <div className="flex flex-col sm:flex-row items-center gap-4 w-full sm:w-auto">
          <div className="relative w-full sm:w-80 group">
            <Search className="absolute left-5 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground group-focus-within:text-primary transition-colors" />
            <input
              className="w-full rounded-[1.5rem] border border-border bg-card py-4 pl-14 pr-6 text-sm font-bold focus:ring-4 focus:ring-primary/10 focus:border-primary outline-none transition-all shadow-sm"
              placeholder={t("Search by name or phone...")}
              value={q}
              onChange={(e) => setQ(e.target.value)}
            />
          </div>
          <button
            onClick={() => setShowAddModal(true)}
            className="h-14 w-full sm:w-auto px-8 rounded-[1.5rem] bg-primary font-bold text-primary-foreground shadow-2xl shadow-primary/30 hover:scale-[1.02] active:scale-[0.98] transition-all flex items-center justify-center gap-3"
          >
            <UserPlus className="h-6 w-6" />
            {t("Add Customer")}
          </button>
        </div>
      </div>

      <motion.div 
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        className="overflow-hidden rounded-[3rem] border border-border bg-card shadow-2xl"
      >
        <div className="overflow-x-auto scrollbar-hide">
          <table className="w-full text-sm">
            <thead className="bg-muted/30 text-[10px] font-bold text-muted-foreground uppercase tracking-[0.3em]">
              <tr className="[&>th]:px-10 [&>th]:py-8 [&>th]:text-right">
                <th>{t("Customer")}</th>
                <th>{t("Contact")}</th>
                <th>{t("Total Spent")}</th>
                <th>{t("Loyalty")}</th>
                <th className="w-[150px]">{t("Actions")}</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border/50">
              <AnimatePresence mode="popLayout">
                {filtered.map((c, idx) => (
                  <motion.tr 
                    layout
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0, transition: { delay: idx * 0.02 } }}
                    exit={{ opacity: 0, scale: 0.95 }}
                    key={c.id} 
                    className="group hover:bg-muted/30 transition-all [&>td]:px-10 [&>td]:py-8 [&>td]:text-right"
                  >
                    <td>
                      <div className="flex items-center gap-5">
                        <div className="h-14 w-14 rounded-2xl bg-primary/10 flex items-center justify-center text-primary font-bold text-lg uppercase group-hover:bg-primary group-hover:text-primary-foreground transition-all group-hover:scale-110 shadow-inner">
                          {c.name[0]}
                        </div>
                        <div className="space-y-0.5">
                          <span className="font-bold text-foreground text-lg block group-hover:text-primary transition-colors">{c.name}</span>
                          <span className="text-[10px] font-bold text-muted-foreground uppercase tracking-widest">{t("Client ID")}: {c.id.slice(-6).toUpperCase()}</span>
                        </div>
                      </div>
                    </td>
                    <td className="text-muted-foreground font-medium">
                      <div className="flex items-center gap-3 bg-muted/50 px-4 py-2 rounded-xl w-fit">
                        <Phone className="h-4 w-4 text-primary" />
                        <span className="font-bold text-foreground" dir="ltr">{c.phone ?? "—"}</span>
                      </div>
                    </td>
                    <td>
                      <div className="flex flex-col">
                        <div className="flex items-center gap-2">
                          <span className="font-bold text-foreground text-xl">{c.totalSpent.toFixed(2)}</span>
                          <TrendingUp className="h-4 w-4 text-emerald-500" />
                        </div>
                        <span className="text-[10px] font-bold text-muted-foreground uppercase tracking-widest">{t("OMR Total")}</span>
                      </div>
                    </td>
                    <td>
                      <div className="inline-flex items-center gap-3 rounded-2xl bg-amber-500/10 px-5 py-2.5 text-xs font-bold text-amber-600 border border-amber-500/20 shadow-sm">
                        <Sparkles className="h-4 w-4" />
                        {c.loyaltyPoints} {t("Points")}
                      </div>
                    </td>
                    <td>
                      <button
                        onClick={() => openHistory(c)}
                        className="h-12 w-12 rounded-2xl border border-border bg-card flex items-center justify-center text-muted-foreground hover:bg-primary/10 hover:text-primary hover:border-primary/20 transition-all shadow-sm hover:scale-110 active:scale-95"
                        title={t("History")}
                      >
                        <History className="h-6 w-6" />
                      </button>
                    </td>
                  </motion.tr>
                ))}
              </AnimatePresence>
              {filtered.length === 0 && !loading && (
                <tr>
                  <td colSpan={5} className="px-10 py-40 text-center">
                    <div className="flex flex-col items-center justify-center gap-6 opacity-20">
                      <Search className="h-20 w-20" />
                      <p className="text-xl font-bold uppercase tracking-[0.3em]">{t("No Customers Found")}</p>
                    </div>
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </motion.div>

      <AnimatePresence>
        {openId && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-6">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setOpenId(null)}
              className="absolute inset-0 bg-black/60 backdrop-blur-xl"
            />
            <motion.div 
              initial={{ opacity: 0, scale: 0.9, y: 40 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 40 }}
              className="relative w-full max-w-6xl rounded-[3rem] border border-border bg-card shadow-2xl overflow-hidden"
            >
              <div className="flex items-center justify-between border-b border-border px-10 py-8 bg-muted/20">
                <div className="flex items-center gap-5">
                  <div className="h-14 w-14 rounded-2xl bg-primary/10 flex items-center justify-center text-primary shadow-inner">
                    <History className="h-7 w-7" />
                  </div>
                  <div className="space-y-0.5">
                    <h2 className="text-2xl font-bold text-foreground">{t("Customer Profile")}</h2>
                    <p className="text-[10px] font-bold text-muted-foreground uppercase tracking-widest">{t("History & Preferences")}</p>
                  </div>
                </div>
                <button
                  onClick={() => setOpenId(null)}
                  className="h-12 w-12 rounded-full hover:bg-muted flex items-center justify-center transition-all hover:rotate-90"
                >
                  <X className="h-6 w-6" />
                </button>
              </div>

              <div className="max-h-[80vh] overflow-auto p-10 scrollbar-hide">
                {!history ? (
                  <div className="flex flex-col items-center justify-center py-40 gap-6 opacity-40">
                    <div className="h-12 w-12 animate-spin rounded-full border-4 border-primary border-t-transparent" />
                    <p className="text-xs font-bold uppercase tracking-[0.2em]">{t("Fetching Data...")}</p>
                  </div>
                ) : (
                  <div className="grid gap-12 lg:grid-cols-3">
                    {/* Notes Section */}
                    <div className="lg:col-span-1 space-y-8">
                      <div className="flex items-center gap-4 text-sm font-bold text-foreground uppercase tracking-[0.2em]">
                        <div className="h-10 w-10 rounded-xl bg-primary/10 flex items-center justify-center text-primary">
                          <FileText className="h-5 w-5" />
                        </div>
                        {t("Notes & Preferences")}
                      </div>
                      <div className="rounded-[2.5rem] border border-border bg-muted/30 p-8 space-y-6 shadow-inner">
                        <textarea
                          className="w-full h-64 rounded-[1.5rem] border border-border bg-card p-6 text-sm font-medium text-foreground focus:ring-4 focus:ring-primary/10 outline-none resize-none transition-all shadow-sm"
                          placeholder={t("Medical History / Preferences / Allergies")}
                          value={notes}
                          onChange={(e) => setNotes(e.target.value)}
                        />
                        <button
                          onClick={handleSaveNotes}
                          disabled={savingNotes}
                          className="group relative flex w-full h-14 items-center justify-center gap-3 rounded-[1.5rem] bg-primary font-bold text-primary-foreground shadow-2xl shadow-primary/30 hover:scale-[1.02] active:scale-95 transition-all disabled:opacity-50 overflow-hidden"
                        >
                          <div className="absolute inset-0 bg-gradient-to-tr from-white/0 via-white/10 to-white/0 translate-x-[-100%] group-hover:translate-x-[100%] transition-transform duration-1000" />
                          <Save className="h-5 w-5 relative z-10" />
                          <span className="relative z-10">{savingNotes ? t("Saving...") : t("Save Changes")}</span>
                        </button>
                      </div>
                    </div>

                    {/* Appointments Section */}
                    <div className="lg:col-span-1 space-y-8">
                      <div className="flex items-center gap-4 text-sm font-bold text-foreground uppercase tracking-[0.2em]">
                        <div className="h-10 w-10 rounded-xl bg-primary/10 flex items-center justify-center text-primary">
                          <Calendar className="h-5 w-5" />
                        </div>
                        {t("Appointments")}
                      </div>
                      <div className="space-y-5">
                        {history.appointments?.length ? (
                          history.appointments.map((a: any, idx: number) => (
                            <motion.div 
                              initial={{ opacity: 0, y: 10 }}
                              animate={{ opacity: 1, y: 0, transition: { delay: idx * 0.05 } }}
                              key={a.id} 
                              className="group rounded-[1.5rem] border border-border bg-muted/50 p-6 transition-all hover:bg-card hover:shadow-xl hover:-translate-y-1"
                            >
                              <div className="flex items-center justify-between mb-4">
                                <div className="flex items-center gap-2 bg-background px-3 py-1.5 rounded-xl border border-border shadow-sm">
                                  <Calendar className="h-3.5 w-3.5 text-primary" />
                                  <span className="text-[10px] font-bold text-foreground uppercase tracking-wider">
                                    {new Date(a.dateTime).toLocaleDateString(i18n.language, { dateStyle: 'medium' })}
                                  </span>
                                </div>
                                <span className={clsx(
                                  "rounded-xl px-3 py-1.5 text-[9px] font-bold uppercase tracking-widest shadow-sm",
                                  a.status === 'COMPLETED' ? "bg-emerald-500/10 text-emerald-600" : "bg-amber-500/10 text-amber-600"
                                )}>
                                  {t(a.status)}
                                </span>
                              </div>
                              <div className="text-base font-bold text-foreground mb-1 group-hover:text-primary transition-colors">{a.service?.name}</div>
                              <div className="flex items-center gap-2 text-[10px] font-bold text-muted-foreground uppercase tracking-widest">
                                <User className="h-3 w-3" />
                                {a.employee?.name}
                              </div>
                            </motion.div>
                          ))
                        ) : (
                          <div className="rounded-[2rem] border border-dashed border-border py-32 text-center opacity-20">
                            <Calendar className="h-12 w-12 mx-auto mb-4" />
                            <p className="text-[10px] font-bold uppercase tracking-[0.2em]">{t("No Appointments")}</p>
                          </div>
                        )}
                      </div>
                    </div>

                    {/* Invoices Section */}
                    <div className="lg:col-span-1 space-y-8">
                      <div className="flex items-center gap-4 text-sm font-bold text-foreground uppercase tracking-[0.2em]">
                        <div className="h-10 w-10 rounded-xl bg-primary/10 flex items-center justify-center text-primary">
                          <Receipt className="h-5 w-5" />
                        </div>
                        {t("Invoices")}
                      </div>
                      <div className="space-y-5">
                        {history.invoices?.length ? (
                          history.invoices.map((inv: any, idx: number) => (
                            <motion.div 
                              initial={{ opacity: 0, y: 10 }}
                              animate={{ opacity: 1, y: 0, transition: { delay: idx * 0.05 } }}
                              key={inv.id} 
                              className="group rounded-[1.5rem] border border-border bg-muted/50 p-6 transition-all hover:bg-card hover:shadow-xl hover:-translate-y-1"
                            >
                              <div className="flex items-center justify-between mb-4">
                                <div className="flex items-center gap-2 bg-background px-3 py-1.5 rounded-xl border border-border shadow-sm">
                                  <Receipt className="h-3.5 w-3.5 text-primary" />
                                  <span className="text-[10px] font-bold text-foreground uppercase tracking-wider">
                                    {new Date(inv.date).toLocaleDateString(i18n.language, { dateStyle: 'medium' })}
                                  </span>
                                </div>
                                <div className="flex items-baseline gap-1">
                                  <span className="text-lg font-bold text-primary">{inv.totalAmount.toFixed(2)}</span>
                                  <span className="text-[9px] font-bold text-muted-foreground uppercase">{t("OMR")}</span>
                                </div>
                              </div>
                              <div className="flex flex-wrap gap-2">
                                {inv.items?.map((it: any) => (
                                  <span key={it.id} className="rounded-xl bg-background border border-border px-3 py-1.5 text-[9px] font-bold text-muted-foreground uppercase tracking-widest group-hover:border-primary/30 transition-colors shadow-sm">
                                    {it.service?.name || it.product?.name}
                                  </span>
                                ))}
                              </div>
                            </motion.div>
                          ))
                        ) : (
                          <div className="rounded-[2rem] border border-dashed border-border py-32 text-center opacity-20">
                            <Receipt className="h-12 w-12 mx-auto mb-4" />
                            <p className="text-[10px] font-bold uppercase tracking-[0.2em]">{t("No Invoices")}</p>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {showAddModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-6">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowAddModal(false)}
              className="absolute inset-0 bg-black/60 backdrop-blur-xl"
            />
            <motion.div 
              initial={{ opacity: 0, scale: 0.9, y: 40 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 40 }}
              className="relative w-full max-w-md rounded-[3rem] border border-border bg-card shadow-2xl overflow-hidden"
            >
              <div className="flex items-center justify-between border-b border-border px-10 py-8 bg-muted/20">
                <div className="flex items-center gap-4">
                  <div className="h-14 w-14 rounded-2xl bg-primary/10 flex items-center justify-center text-primary shadow-inner">
                    <UserPlus className="h-7 w-7" />
                  </div>
                  <div className="space-y-0.5">
                    <h2 className="text-2xl font-bold text-foreground">{t("Add Customer")}</h2>
                    <p className="text-[10px] font-bold text-muted-foreground uppercase tracking-widest">{t("Create New Client")}</p>
                  </div>
                </div>
                <button
                  onClick={() => setShowAddModal(false)}
                  className="h-12 w-12 rounded-full hover:bg-muted flex items-center justify-center transition-all hover:rotate-90"
                >
                  <X className="h-6 w-6" />
                </button>
              </div>

              <div className="p-10 space-y-8">
                <div className="space-y-3">
                  <label className="text-[10px] font-bold text-muted-foreground uppercase tracking-[0.2em] ml-2">{t("Full Name")}</label>
                  <div className="relative">
                    <User className="absolute left-5 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
                    <input
                      className="w-full rounded-[1.5rem] border border-border bg-muted/30 pl-14 pr-6 py-4.5 text-sm font-bold focus:ring-4 focus:ring-primary/10 focus:border-primary outline-none transition-all shadow-inner"
                      placeholder={t("Enter customer name")}
                      value={newName}
                      onChange={(e) => setNewName(e.target.value)}
                    />
                  </div>
                </div>
                <div className="space-y-3">
                  <label className="text-[10px] font-bold text-muted-foreground uppercase tracking-[0.2em] ml-2">{t("Phone Number")}</label>
                  <div className="relative">
                    <Phone className="absolute left-5 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
                    <input
                      className="w-full rounded-[1.5rem] border border-border bg-muted/30 pl-14 pr-6 py-4.5 text-sm font-bold focus:ring-4 focus:ring-primary/10 focus:border-primary outline-none transition-all text-left shadow-inner"
                      dir="ltr"
                      placeholder="968XXXXXXXX"
                      value={newPhone}
                      onChange={(e) => setNewPhone(e.target.value)}
                    />
                  </div>
                </div>

                <button
                  disabled={adding}
                  onClick={handleAddCustomer}
                  className="group relative w-full h-16 rounded-[2rem] bg-primary font-bold text-primary-foreground shadow-2xl shadow-primary/30 hover:scale-[1.02] active:scale-95 transition-all disabled:opacity-50 overflow-hidden flex items-center justify-center gap-3"
                >
                  <div className="absolute inset-0 bg-gradient-to-tr from-white/0 via-white/10 to-white/0 translate-x-[-100%] group-hover:translate-x-[100%] transition-transform duration-1000" />
                  <CheckCircle2 className="h-6 w-6 relative z-10" />
                  <span className="text-lg relative z-10">{adding ? t("Creating...") : t("Create Customer")}</span>
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
