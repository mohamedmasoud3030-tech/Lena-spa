import React, { createContext, useContext, useEffect, useMemo, useState } from "react";
import { api } from "./api";

declare global {
  interface Window {
    api: typeof api;
  }
}

type Session = { userId: string; role: "ADMIN" | "STAFF"; username: string } | null;

const Ctx = createContext<{
  me: Session;
  refresh: () => Promise<void>;
  login: (u: string, p: string) => Promise<void>;
  logout: () => Promise<void>;
}>({
  me: null,
  refresh: async () => {},
  login: async () => {},
  logout: async () => {},
});

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [me, setMe] = useState<Session>(null);

  async function refresh() {
    try {
      const s = await api.auth.me();
      setMe(s);
    } catch (err: any) {
      if (err.message !== "Not logged in") {
        console.error("Auth refresh failed:", err);
      }
      setMe(null);
    }
  }

  async function login(username: string, password: string) {
    const s = await api.auth.login({ username, password });
    setMe(s);
  }

  async function logout() {
    await api.auth.logout();
    setMe(null);
  }

  useEffect(() => {
    void refresh();
  }, []);

  const value = useMemo(() => ({ me, refresh, login, logout }), [me]);
  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export function useAuth() {
  return useContext(Ctx);
}
